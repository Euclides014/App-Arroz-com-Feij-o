package com.example.cursoandroidfirebase2.Classes;

public class Cardapio {

    private String keyProduto;
    private String descricao;
    private String nomePrato;
    private String serveQtd;
    private String urlImagem;
    private String preco;

    public String getKeyProduto() {
        return keyProduto;
    }

    public void setKeyProduto(String keyProduto) {
        this.keyProduto = keyProduto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNomePrato() {
        return nomePrato;
    }

    public void setNomePrato(String nomePrato) {
        this.nomePrato = nomePrato;
    }

    public String getServeQtd() {
        return serveQtd;
    }

    public void setServeQtd(String serveQtd) {
        this.serveQtd = serveQtd;
    }

    public String getUrlImagem() {
        return urlImagem;
    }

    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }
}
